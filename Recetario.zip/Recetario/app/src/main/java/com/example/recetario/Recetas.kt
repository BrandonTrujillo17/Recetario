package com.example.recetario

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.io.IOException

class Recetas : AppCompatActivity() {

    val recetasDesayuno = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recetas)



        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)
        val btnConsultarMas = findViewById<Button>(R.id.btnConsultar)
        val btnCancelar = findViewById<Button>(R.id.btnCancelar)
        val listaRecetas = findViewById<ListView>(R.id.listaRecetas)
        val tvCategoria = findViewById<TextView>(R.id.tvCategoria)

        val bundle = intent.extras
        val categoriaElegida = bundle?.getString("eleccion")



        if(categoriaElegida == "Desayuno"){
            llenarLista(listaRecetas, categoriaElegida)
            tvCategoria.setText(categoriaElegida+"s")
        }

        if(categoriaElegida == "Comida"){
            llenarLista(listaRecetas, categoriaElegida)
            tvCategoria.setText(categoriaElegida+"s")
        }

        if(categoriaElegida == "Cena"){
            llenarLista(listaRecetas, categoriaElegida)
            tvCategoria.setText(categoriaElegida+"s")
        }

        btnRegistrar.setOnClickListener(){
            val intento1 = Intent(this, Registrar::class.java)
            startActivity(intento1)
        }


        listaRecetas.setOnItemClickListener(){ adapterView, view, i, l ->
            var recetaSeleccionada:String = ""
            recetaSeleccionada = recetasDesayuno[i]
            val intento1 = Intent(this, Editar_Eliminar::class.java)
            intento1.putExtra("seleccionReceta", recetaSeleccionada)
            startActivity(intento1)
        }

        btnConsultarMas.setOnClickListener(){
            val intento1 = Intent(this, Navegador::class.java)
            startActivity(intento1)
        }

        btnCancelar.setOnClickListener(){
            val intento1 = Intent(this, MainActivity::class.java)
            startActivity(intento1)
        }

    }

    fun llenarLista(listaRecetas: ListView, categoriaElegida: String){
        try{
            val admin = AdminSQLite(this, "Recetas", null, 1)
            val bd = admin.writableDatabase
            val fila = bd.rawQuery("SELECT nombre from recetario where categoria = '${categoriaElegida}'", null)

            while (fila.moveToNext()){
                val nombreReceta = fila.getString(0)
                recetasDesayuno.add(nombreReceta)
            }

            val adaptador1 = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, recetasDesayuno)
            listaRecetas.adapter = adaptador1

            bd.close()

        }catch(e:IOException){
            Toast.makeText(this, "Ocurrió un error", Toast.LENGTH_LONG).show()
            println("Error: " + e.message)
        }
    }

}

