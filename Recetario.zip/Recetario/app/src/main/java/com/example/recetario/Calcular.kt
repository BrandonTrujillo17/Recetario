package com.example.recetario

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class Calcular : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calcular)

        val bundle = intent.extras
        val recetaElegida = bundle?.getString("receta")
        val cantidadPersonas: Int? = bundle?.getInt("CantidadPersonas")

        val txtNombre = findViewById<EditText>(R.id.txtNombrePlatillo)
        val txtIngrediente1 = findViewById<EditText>(R.id.txtIngrdiente1)
        val txtIngrediente2 = findViewById<EditText>(R.id.txtIngrediente2)
        val txtIngrediente3 = findViewById<EditText>(R.id.txtIngrediente3)
        val txtIngrediente4 = findViewById<EditText>(R.id.txtIngrediente4)
        val txtIngrediente5 = findViewById<EditText>(R.id.txtIngrediente5)

        val txtCantidad1 = findViewById<EditText>(R.id.txtCantidad1)
        val txtCantidad2 = findViewById<EditText>(R.id.txtCantidad2)
        val txtCantidad3 = findViewById<EditText>(R.id.txtCantidad3)
        val txtCantidad4 = findViewById<EditText>(R.id.txtCantidad4)
        val txtCantidad5 = findViewById<EditText>(R.id.txtCantidad5)

        val btnCalcularCantidad = findViewById<Button>(R.id.btnCalcularCantidad)
        val btnCancelar = findViewById<Button>(R.id.btnCancelarCalculo)
        val txtCantidadPersonas = findViewById<EditText>(R.id.txtCantidadPersonas)

        var cantidad1 = 0.0
        var cantidad2 = 0.0
        var cantidad3 = 0.0
        var cantidad4 = 0.0
        var cantidad5 = 0.0

        val admin = AdminSQLite(this, "Recetas", null, 1)
        val bd = admin.writableDatabase
        val fila = bd.rawQuery("SELECT * from recetario where nombre = '${recetaElegida}'", null)
        if(fila.moveToFirst()) {
            txtNombre.setText(fila.getString(0))
            txtIngrediente1.setText(fila.getString(1))
            cantidad1 = fila.getString(2).toDouble()
            txtIngrediente2.setText(fila.getString(3))
            cantidad2 = fila.getString(4).toDouble()
            txtIngrediente3.setText(fila.getString(5))
            cantidad3 = fila.getString(6).toDouble()
            txtIngrediente4.setText(fila.getString(7))
            cantidad4 = fila.getString(8).toDouble()
            txtIngrediente5.setText(fila.getString(9))
            cantidad5 = fila.getString(10).toDouble()

            bd.close()
        }




        btnCalcularCantidad.setOnClickListener{
            val nuevaCantidadPersonas = txtCantidadPersonas.text.toString().toInt()
            cantidad1 = (cantidad1/ cantidadPersonas!!) * nuevaCantidadPersonas
            cantidad2 = (cantidad2/ cantidadPersonas) * nuevaCantidadPersonas
            cantidad3 = (cantidad3/ cantidadPersonas) * nuevaCantidadPersonas
            cantidad4 = (cantidad4/ cantidadPersonas) * nuevaCantidadPersonas
            cantidad5 = (cantidad5/ cantidadPersonas) * nuevaCantidadPersonas

            txtCantidad1.setText(cantidad1.toString())
            txtCantidad2.setText(cantidad2.toString())
            txtCantidad3.setText(cantidad3.toString())
            txtCantidad4.setText(cantidad4.toString())
            txtCantidad5.setText(cantidad5.toString())
        }
        btnCancelar.setOnClickListener(){
            finish()
        }
    }
}