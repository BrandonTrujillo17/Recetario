package com.example.recetario

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner

class Calcular : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calcular)

        val bundle = intent.extras
        val recetaElegida = bundle?.getString("receta")

        val txtNombre = findViewById<EditText>(R.id.txtNombrePlatillo)
        val txtIngrediente1 = findViewById<EditText>(R.id.txtIngrdiente1)
        val txtIngrediente2 = findViewById<EditText>(R.id.txtIngrediente2)
        val txtIngrediente3 = findViewById<EditText>(R.id.txtIngrediente3)
        val txtIngrediente4 = findViewById<EditText>(R.id.txtIngrediente4)
        val txtIngrediente5 = findViewById<EditText>(R.id.txtIngrediente5)

        val txtCantidad1 = findViewById<EditText>(R.id.txtCantidad1)
        val txtCantidad2 = findViewById<EditText>(R.id.txtCantidad2)
        val txtCantidad3 = findViewById<EditText>(R.id.txtCantidad3)
        val txtCantidad4 = findViewById<EditText>(R.id.txtCantidad4)
        val txtCantidad5 = findViewById<EditText>(R.id.txtCantidad5)

        val btnCalcularCantidad = findViewById<Button>(R.id.btnCalcularCantidad)
        val btnCancelar = findViewById<Button>(R.id.btnCancelarCalculo)
        val txtCantidadPersonas = findViewById<EditText>(R.id.txtCantidadPersonas)

        var cantidad1 = 0
        var cantidad2 = 0
        var cantidad3 = 0
        var cantidad4 = 0
        var cantidad5 = 0

        val admin = AdminSQLite(this, "Recetas", null, 1)
        val bd = admin.writableDatabase
        val fila = bd.rawQuery("SELECT * from recetario where nombre = '${recetaElegida}'", null)
        if(fila.moveToFirst()) {
            txtNombre.setText(fila.getString(0))
            txtIngrediente1.setText(fila.getString(1))
            cantidad1 = fila.getString(2).toInt()
            txtIngrediente2.setText(fila.getString(3))
            cantidad2 = fila.getString(4).toInt()
            txtIngrediente3.setText(fila.getString(5))
            cantidad3 = fila.getString(6).toInt()
            txtIngrediente4.setText(fila.getString(7))
            cantidad4 = fila.getString(8).toInt()
            txtIngrediente5.setText(fila.getString(9))
            cantidad5 = fila.getString(10).toInt()
        }




        btnCalcularCantidad.setOnClickListener{
            var cantidadPersonas = txtCantidadPersonas.text.toString().toInt()
            cantidad1 *= cantidadPersonas
            cantidad2 *= cantidadPersonas
            cantidad3 *= cantidadPersonas
            cantidad4 *= cantidadPersonas
            cantidad5 *= cantidadPersonas

            txtCantidad1.setText(cantidad1.toString())
            txtCantidad2.setText(cantidad2.toString())
            txtCantidad3.setText(cantidad3.toString())
            txtCantidad4.setText(cantidad4.toString())
            txtCantidad5.setText(cantidad5.toString())
        }
        btnCancelar.setOnClickListener(){
            finish()
        }
    }
}