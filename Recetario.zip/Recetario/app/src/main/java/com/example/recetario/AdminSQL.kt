package com.example.recetario

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteDatabase.CursorFactory
class AdminSQLite (context: Context, name:String, factory:CursorFactory?, version: Int): SQLiteOpenHelper(context, name, factory, version){

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("create table recetario (nombre text primary key, ingrediente1 text, cantidad1 real, ingrediente2 text, cantidad2 real, ingrediente3 text, cantidad3 real, ingrediente4 text, cantidad4 real, ingrediente5 text, cantidad5 real, categoria text, cantidadPersonas text)")
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {

    }


}