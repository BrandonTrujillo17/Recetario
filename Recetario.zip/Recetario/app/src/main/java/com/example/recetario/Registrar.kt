package com.example.recetario

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.io.IOException

class Registrar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registrar)

        val txtNombre = findViewById<EditText>(R.id.txtNombrePlatillo)
        val txtIngrediente1 = findViewById<EditText>(R.id.txtIngrdiente1)
        val txtIngrediente2 = findViewById<EditText>(R.id.txtIngrediente2)
        val txtIngrediente3 = findViewById<EditText>(R.id.txtIngrediente3)
        val txtIngrediente4 = findViewById<EditText>(R.id.txtIngrediente4)
        val txtIngrediente5 = findViewById<EditText>(R.id.txtIngrediente5)
        val txtCantidad1 = findViewById<EditText>(R.id.txtCantidad1)
        val txtCantidad2 = findViewById<EditText>(R.id.txtCantidad2)
        val txtCantidad3 = findViewById<EditText>(R.id.txtCantidad3)
        val txtCantidad4 = findViewById<EditText>(R.id.txtCantidad4)
        val txtCantidad5 = findViewById<EditText>(R.id.txtCantidades5)
        val txtCantidadPersonas = findViewById<EditText>(R.id.txtCantidadDePersonas)

        val btnGuardar = findViewById<Button>(R.id.btnGuardar)
        val btnCancelar = findViewById<Button>(R.id.btnCancelar)


        val spCategoria = findViewById<Spinner>(R.id.spCategorias)
        val categorias = arrayOf("Desayuno", "Comida", "Cena")
        val adaptador = ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, categorias)
        spCategoria.adapter = adaptador


        btnGuardar.setOnClickListener() {
            try {
                val admin = AdminSQLite(this, "Recetas", null, 1)
                val bd = admin.writableDatabase
                val registro = ContentValues()
                val categoriaSeleccionada = spCategoria.selectedItem.toString()

                if(txtNombre.text.toString().isNotEmpty() || txtCantidadPersonas.text.toString().isNotEmpty()){
                    if(txtIngrediente1.text.toString().isNotEmpty() || txtCantidad1.text.toString().isNotEmpty() || txtIngrediente2.text.toString().isNotEmpty() ||
                        txtCantidad2.text.toString().isNotEmpty() || txtIngrediente3.text.toString().isNotEmpty() || txtCantidad3.text.toString().isNotEmpty()){
                        if(txtIngrediente4.text.toString().isEmpty() || txtCantidad4.text.toString().isEmpty() ||
                            txtIngrediente5.text.toString().isEmpty() || txtCantidad5.text.toString().isEmpty()){
                            registro.put("nombre", txtNombre.text.toString())
                            registro.put("ingrediente1", txtIngrediente1.text.toString())
                            registro.put("cantidad1", txtCantidad1.text.toString())
                            registro.put("ingrediente2", txtIngrediente2.text.toString())
                            registro.put("cantidad2", txtCantidad2.text.toString())
                            registro.put("ingrediente3", txtIngrediente3.text.toString())
                            registro.put("cantidad3", txtCantidad3.text.toString())
                            registro.put("ingrediente4", "Ninguno")
                            registro.put("cantidad4", "0.0")
                            registro.put("ingrediente5", "Ninguno")
                            registro.put("cantidad5", "0.0")
                            registro.put("categoria", categoriaSeleccionada)
                            registro.put("cantidadPersonas", txtCantidadPersonas.text.toString())

                            val resultado = bd.insert("recetario", null, registro)
                            bd.close()

                            if (resultado > 0) {
                                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()
                                volverARecetario(categoriaSeleccionada)
                            } else {
                                Toast.makeText(this, "Registro NO exitoso", Toast.LENGTH_SHORT).show()
                            }
                        }else{
                            registro.put("nombre", txtNombre.text.toString())
                            registro.put("ingrediente1", txtIngrediente1.text.toString())
                            registro.put("cantidad1", txtCantidad1.text.toString())
                            registro.put("ingrediente2", txtIngrediente2.text.toString())
                            registro.put("cantidad2", txtCantidad2.text.toString())
                            registro.put("ingrediente3", txtIngrediente3.text.toString())
                            registro.put("cantidad3", txtCantidad3.text.toString())
                            registro.put("ingrediente4", txtIngrediente4.text.toString())
                            registro.put("cantidad4", txtCantidad4.text.toString())
                            registro.put("ingrediente5", txtIngrediente5.text.toString())
                            registro.put("cantidad5", txtCantidad5.text.toString())
                            registro.put("categoria", categoriaSeleccionada)
                            registro.put("cantidadPersonas", txtCantidadPersonas.text.toString())

                            val resultado = bd.insert("recetario", null, registro)
                            bd.close()

                            if (resultado > 0) {
                                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()
                                volverARecetario(categoriaSeleccionada)
                            } else {
                                Toast.makeText(this, "Registro NO exitoso", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }else{
                        Toast.makeText(this, "Debe llenar al menos 3 ingredientes con su cantidad", Toast.LENGTH_LONG).show()
                    }

                }else{
                    Toast.makeText(this, "El nombre y la cantidad son necesarios", Toast.LENGTH_LONG).show()
                }

            } catch (e: IOException) {
                Toast.makeText(this, "Ha ocurrido un error", Toast.LENGTH_LONG).show()
                println("Error:" + e.message)
            }
        }

        btnCancelar.setOnClickListener(){
            volverARecetario("Desayuno")
        }


    }

    fun volverARecetario(categoriaSeleccionada: String){
        val intento1 = Intent(this, Recetas::class.java)
        intento1.putExtra("eleccion", categoriaSeleccionada)
        startActivity(intento1)
    }
}