package com.example.recetario

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*


class Editar_Eliminar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_eliminar)

        val txtNombre = findViewById<EditText>(R.id.txtNombrePlatillo)
        val spCategoria = findViewById<Spinner>(R.id.spCategorias)
        val txtIngrediente1 = findViewById<EditText>(R.id.txtIngrdiente1)
        val txtIngrediente2 = findViewById<EditText>(R.id.txtIngrediente2)
        val txtIngrediente3 = findViewById<EditText>(R.id.txtIngrediente3)
        val txtIngrediente4 = findViewById<EditText>(R.id.txtIngrediente4)
        val txtIngrediente5 = findViewById<EditText>(R.id.txtIngrediente5)
        val txtCantidad1 = findViewById<EditText>(R.id.txtCantidad1)
        val txtCantidad2 = findViewById<EditText>(R.id.txtCantidad2)
        val txtCantidad3 = findViewById<EditText>(R.id.txtCantidad3)
        val txtCantidad4 = findViewById<EditText>(R.id.txtCantidad4)
        val txtCantidad5 = findViewById<EditText>(R.id.txtCantidad5)

        val btnCancelar = findViewById<Button>(R.id.btnCancelar)
        val btnEliminar = findViewById<Button>(R.id.btnEliminar)
        val btnEditar = findViewById<Button>(R.id.btnEditar)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)

        val bundle = intent.extras
        val recetaElegida = bundle?.getString("seleccionReceta")
        var nombreAnterior = ""
        var categoriaActual = ""


        //llenar datos
        val admin = AdminSQLite(this, "Recetas", null, 1)
        val bd = admin.writableDatabase
        val fila = bd.rawQuery("SELECT * from recetario where nombre = '${recetaElegida}'", null)
        if(fila.moveToFirst()){
            txtNombre.setText(fila.getString(0))
            nombreAnterior = fila.getString(0)
            txtIngrediente1.setText(fila.getString(1))
            txtCantidad1.setText(fila.getString(2))
            txtIngrediente2.setText(fila.getString(3))
            txtCantidad2.setText(fila.getString(4))
            txtIngrediente3.setText(fila.getString(5))
            txtCantidad3.setText(fila.getString(6))
            txtIngrediente4.setText(fila.getString(7))
            txtCantidad4.setText(fila.getString(8))
            txtIngrediente5.setText(fila.getString(9))
            txtCantidad5.setText(fila.getString(10))


            //llenar spinner
            val categorias = arrayOf("Desayuno", "Comida", "Cena")
            val adaptador = ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, categorias)
            spCategoria.adapter = adaptador
            if(fila.getString(11) == "Desayuno"){
                spCategoria.setSelection(0)
                categoriaActual = "Desayuno"
            }
            if(fila.getString(11) == "Comida"){
                spCategoria.setSelection(1)
                categoriaActual = "Comida"
            }
            if(fila.getString(11) == "Cena"){
                spCategoria.setSelection(2)
                categoriaActual = "Cena"
            }
        }

        btnCancelar.setOnClickListener(){
            volverARecetario(categoriaActual)
        }

        btnEliminar.setOnClickListener(){
            val admin = AdminSQLite(this, "Recetas", null, 1)
            val bd = admin.writableDatabase
            val resultado = bd.delete("recetario","nombre = '${nombreAnterior}'", null)

            if(resultado == 1){
                Toast.makeText(this, "Eliminación exitosa", Toast.LENGTH_SHORT).show()
                volverARecetario(categoriaActual)
            }else{
                Toast.makeText(this, "Eliminación NO exitosa", Toast.LENGTH_SHORT).show()
            }
        }

        btnEditar.setOnClickListener(){
            val admin = AdminSQLite(this, "Recetas", null, 1)
            val bd = admin.writableDatabase
            val registro = ContentValues()
            val categoriaSeleccionada = spCategoria.selectedItem.toString()

            registro.put("nombre", txtNombre.text.toString())
            registro.put("ingrediente1", txtIngrediente1.text.toString())
            registro.put("cantidad1", txtCantidad1.text.toString())
            registro.put("ingrediente2", txtIngrediente2.text.toString())
            registro.put("cantidad2", txtCantidad2.text.toString())
            registro.put("ingrediente3", txtIngrediente3.text.toString())
            registro.put("cantidad3", txtCantidad3.text.toString())
            registro.put("ingrediente4", txtIngrediente4.text.toString())
            registro.put("cantidad4", txtCantidad4.text.toString())
            registro.put("ingrediente5", txtIngrediente5.text.toString())
            registro.put("cantidad5", txtCantidad5.text.toString())
            registro.put("categoria", categoriaSeleccionada)

            val resultado = bd.update("recetario", registro, "nombre = '${nombreAnterior}'", null)
            bd.close()

            if(resultado == 1){
                Toast.makeText(this, "Edición exitosa", Toast.LENGTH_SHORT).show()
                volverARecetario(categoriaSeleccionada)
            }else{
                Toast.makeText(this, "Edición NO exitosa", Toast.LENGTH_SHORT).show()
            }
        }

        btnCalcular.setOnClickListener(){
            val intento1 = Intent(this, Calcular::class.java)
            intento1.putExtra("receta", nombreAnterior)
            startActivity(intento1)
        }

    }
    fun volverARecetario(categoriaSeleccionada: String){
        val intento1 = Intent(this, Recetas::class.java)
        intento1.putExtra("eleccion", categoriaSeleccionada)
        startActivity(intento1)
    }

}