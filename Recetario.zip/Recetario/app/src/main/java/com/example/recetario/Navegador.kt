package com.example.recetario

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.widget.Button

class Navegador : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_navegador)
        val btnCancelar = findViewById<Button>(R.id.btnCancelar)
        btnCancelar.setOnClickListener(){
            volverARecetario("Desayuno")
        }

        val navegador = findViewById<WebView>(R.id.webView)
        navegador.loadUrl("https://www.cocinafacil.com.mx/recetario/")
    }
    fun volverARecetario(categoriaSeleccionada: String){
        val intento1 = Intent(this, Recetas::class.java)
        intento1.putExtra("eleccion", categoriaSeleccionada)
        startActivity(intento1)
    }
}