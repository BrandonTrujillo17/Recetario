package com.example.recetario

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnDesayuno = findViewById<Button>(R.id.btnDesayuno)
        val btnComida = findViewById<Button>(R.id.btnComida)
        val btnCena = findViewById<Button>(R.id.btnCena)

        var eleccion = ""

        btnDesayuno.setOnClickListener(){
            eleccion = "Desayuno";
            val intento1 = Intent(this, Recetas::class.java)
            intento1.putExtra("eleccion", eleccion)
            startActivity(intento1)

        }

        btnComida.setOnClickListener(){
            eleccion = "Comida"
            val intento1 = Intent(this, Recetas::class.java)
            intento1.putExtra("eleccion", eleccion)
            startActivity(intento1)

        }

        btnCena.setOnClickListener(){
            eleccion = "Cena"
            val intento1 = Intent(this, Recetas::class.java)
            intento1.putExtra("eleccion", eleccion)
            startActivity(intento1)

        }

    }
}